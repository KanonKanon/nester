from distutils.core import setup

setup(
		name = 'nester',
		version = '1.0.0',
		py_modules = ['nester'],
		author = 'Kanon',
		author_email = '123@qq.com',
		url = 'http://www.headfirstlabs.com',
		description = 'a simple printer of nested lists'
	)